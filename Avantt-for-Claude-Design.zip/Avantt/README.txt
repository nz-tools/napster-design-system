Napster brand font: Avantt

This bundle contains the four Avantt weights in both TTF and WOFF2 formats.

UPLOAD TO CLAUDE DESIGN: use the TTF files.
Claude Design's font registry accepts TTF (and OTF), but does not accept
WOFF2.

  Avantt-Medium.ttf      (weight 500)
  Avantt-SemiBold.ttf    (weight 600)
  Avantt-Bold.ttf        (weight 700)
  Avantt-ExtraBold.ttf   (weight 800)

The WOFF2 files in this bundle are for non-Claude-Design contexts
(production HTML, generated artifacts, marketing sites where smaller
web-native font files are preferred). You do not need to upload them to
Claude Design.

All files have corrected metadata: family="Avantt" across all weights,
with the OS/2 weight class set correctly. This fixes a bug in the
original Displaay foundry packaging where Medium/SemiBold/ExtraBold
were declared as separate families.

Licensed from Displaay Type Foundry.
